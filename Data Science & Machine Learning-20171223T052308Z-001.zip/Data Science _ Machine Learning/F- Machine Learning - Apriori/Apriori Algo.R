
#Load the data
orders_data = read.csv('C:\\R\\OrderDetails.csv', header=TRUE, stringsAsFactors=FALSE)
orders_data <- orders_data[,c(1,3)]

#sort
orders_data_sorted <- orders_data[order(orders_data$SalesOrderID),]
orders_data_sorted$SalesOrderID <- as.numeric(orders_data_sorted$SalesOrderID)

#install.packages("plyr", dependencies= TRUE)
require("plyr")
orders_ProdList <- ddply(orders_data_sorted,c("SalesOrderID"), 
                     function(df1)paste(df1$ProductID, 
                                        collapse = ","))


orders_ProdList$SalesOrderID <- NULL

#Rename column headers for ease of use
colnames(orders_ProdList) <- c("ProdList")
orders_ProdList$ProdList

#Write CSVs
write.csv(orders_ProdList,"C:\\R\\orders_ProdList.csv", quote=FALSE, row.names=TRUE)

#install.packages("arules");, dependencies=TRUE)
library(arules)



#options(download.file.method ="wget")
#Change the description file. Change the Depends: R (>= 3.1.2), Matrix (>= 1.2-0)
#setwd("~/R/arules_1.5-2")
#install.packages("arules", type="source", repos=NULL)

txn = read.transactions(file="C:\\R\\orders_ProdList.csv", rm.duplicates= TRUE, format="basket",sep=",",cols=1)
txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)
itemFrequencyPlot(txn, topN = 10)

basket_rules <- apriori(txn,parameter = list(sup = 0.02, conf = 0.5,target="rules")
                        )
if(sessionInfo()['basePkgs']=="tm" | sessionInfo()['otherPkgs']=="tm"){
  detach(package:tm, unload=TRUE)
}

inspect(sort(basket_rules,by='lift')[1:20])


#install.packages("arulesViz")
#options(download.file.method ="")
library(arulesViz)
plot(basket_rules)
plot(basket_rules, method = "grouped", control = list(k = 5))
plot(basket_rules, method="graph", control=list(type="items"))
plot(basket_rules,measure=c("support","lift"),shading="confidence",interactive=T)

#setwd("~/R/flexmix_2.3-14")
#install.packages("flexmix", type="source", repos=NULL)

install.packages("lme4")