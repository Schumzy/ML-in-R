
library('ggplot2');
args = commandArgs(trailingOnly=TRUE);

#Load the data
#Arg_data <- read.csv('C:\\R\\day.csv', header=TRUE, stringsAsFactors=FALSE)
Arg_data <- read.csv(args[1], header=TRUE, stringsAsFactors=FALSE)

#png(filename='C:\\R\\CommandLine\\SavedFile.png')
png(filename=args[2])

Arg_data$Date = as.Date(Arg_data$dteday)
ggplot(Arg_data, aes(x = Date, y = cnt)) + geom_line() + scale_x_date('month')  + ylab("MyGraph")

dev.off()

