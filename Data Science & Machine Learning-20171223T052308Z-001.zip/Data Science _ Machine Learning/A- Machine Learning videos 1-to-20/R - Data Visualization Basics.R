load("c:\\R\\MyData.Rdata")
MyDF_cust<- read.csv("c:\\R\\Customer_Age_Income.csv",stringsAsFactors = FALSE);
loadmycsv <- read.csv("c:\\R\\Prod_inv.csv",stringsAsFactors = FALSE);
loadmycsv


#Boxplot
boxplot(loadmycsv$Inventory)
boxplot(loadmycsv$Inventory, main="My Chart")
boxplot(loadmycsv$Inventory, main="My Chart",ylab="Inventory (x10 lbs)")
boxplot(loadmycsv$Price, main="My Chart",ylab="Price ($$)")
boxplot(loadmycsv$Price, main="My Chart",ylab="Price ($$)", xlab="My x axis")

#Histogram
hist(loadmycsv$Inventory)
hist(loadmycsv$Inventory, main="My Chart")
hist(loadmycsv$Inventory, main="My Chart",xlab="Inventory (x10 lbs)")
hist(loadmycsv$Price, main="My Chart",ylab="Price ($$)")

#ScatterPlot
plot(x=MyDF_cust$Age, y=MyDF_cust$SalesAmt, xlab = "Age",ylab="Income")
