balanceCSV <- read.csv("c:\\R\\balance-scale.csv")
str(balanceCSV)
summary(balanceCSV)

normalize <- function(y) {return ((y - min(y)) / (max(y) - min(y)))} 
balanceCSV_normalized <- as.data.frame(lapply(balanceCSV[2:5], normalize))
summary(balanceCSV_normalized)

balanceDF <- balanceCSV[order(runif(nrow(balanceCSV))),]
tail(balanceDF,25)

balanceDF_train <- balanceDF[1:600,]
balanceDF_test <- balanceDF[601:625,]

nrow(balanceDF_train)
nrow(balanceDF_test)

require(class)
sqrt(nrow(balanceDF))

balanceDF_train_labels <- balanceDF_train[,1]
balanceDF_test_labels <- balanceDF_test[,1]
balanceDF_test_labels

knn_model<- knn(train = balanceDF_train, test = balanceDF_test, cl = balanceDF_train_labels, k = 25)
summary(knn_model)

table(balanceDF_test_labels,knn_model)
