#Read the Youtube_Spam.csv file 

Youtube_Spam <- read.csv("c:\\R\\Youtube_Spam.csv", stringsAsFactors = FALSE) 
Youtube_Spam <- Youtube_Spam[,4:5]
str(Youtube_Spam)
head(Youtube_Spam)

#convert the type element into Factors 0 - HAM 1- SPAM
Youtube_Spam$CLASS <- factor(Youtube_Spam$CLASS)
table(Youtube_Spam$CLASS)

#Install text mining - tm package. If you receive Slam package related error, if your R version is below 3.3.2 
#use the below section.
#install.packages("tm") 

#Slam error - option -1 if it throws you an error - try option-2
#install.packages("slam") 

#Slam error - option -2 
#install.packages('devtools')
#library(devtools)
#slam_url <- "https://cran.r-project.org/src/contrib/Archive/slam/slam_0.1-37.tar.gz"
#install_url(slam_url)


library(tm) 


#use VCorpus function from tm package - Volatile corpus
Youtube_Spam_VC <- VCorpus(VectorSource(Youtube_Spam$CONTENT)) 

#Clean up the data, divide the text into individual words using tm_map()

#lower case
Youtube_Spam_Clean <- tm_map(Youtube_Spam_VC,content_transformer(tolower)) 
#remove filler words such as to, and, but, and or these words are stopwords()
Youtube_Spam_Clean <- tm_map(Youtube_Spam_Clean,removeWords,stopwords()) 
#remove punctuations
Youtube_Spam_Clean <- tm_map(Youtube_Spam_Clean, removePunctuation) 
#remove numbers
Youtube_Spam_Clean <- tm_map(Youtube_Spam_Clean, removeNumbers)
#strip white spaces;
Youtube_Spam_Clean <- tm_map(Youtube_Spam_Clean, stripWhitespace) 
#Stemming;
Youtube_Spam_Clean <- tm_map(Youtube_Spam_Clean, stemDocument)

#World Cloud
#install.packages("wordcloud") 
library(wordcloud) 
wordcloud(Youtube_Spam_Clean, min.freq = 10, 
          max.words =300, scale=c(2,.5), 
          random.order = FALSE,rot.per=.5,vfont=c("sans serif","plain"),colors=palette())
warnings()

#install.packages("SnowballC") 
library(SnowballC) 

#Creating a DTM sparse matrix 
Youtube_Spam_DTM <- DocumentTermMatrix(Youtube_Spam_Clean)
str(Youtube_Spam_DTM)

#split data for training and testing.
Youtube_DTM_train <- Youtube_Spam_DTM[1:1500, ] 
Youtube_DTM_test  <- Youtube_Spam_DTM[1501:1956, ] 

#Labels:
Youtube_train_lbl <- Youtube_Spam[1:1500, ]$CLASS 
Youtube_test_lbl  <- Youtube_Spam[1501:1956, ] $CLASS

#check table:
prop.table(table(Youtube_train_lbl))
prop.table(table(Youtube_test_lbl)) 


#find frequent terms - terms appearing in the data for more than 10 times.
Youtube_DTM_10 <- findFreqTerms(Youtube_DTM_train, 10)
str(Youtube_DTM_10)

#this would give all the rows containing the frequent words.
Youtube_DTM_10_train <- Youtube_DTM_train[ , Youtube_DTM_10] 
Youtube_DTM_10_test <- Youtube_DTM_test[ , Youtube_DTM_10]

str(Youtube_DTM_10_train)
str(Youtube_DTM_10_test)

#convert into yes or no
Cnt_Boolean <- function(param) {param <- ifelse(param > 0, "Yes", "No")  } 
Youtube_train <- apply(Youtube_DTM_10_train, MARGIN = 2,Cnt_Boolean) 
Youtube_test <- apply(Youtube_DTM_10_test, MARGIN = 2, Cnt_Boolean)

#Apply Naive Bayes theorom
#install.packages("e1071") 
library(e1071) 
Youtube_NB_Model <- naiveBayes(Youtube_train, Youtube_train_lbl)
Youtube_NB_Pred <- predict(Youtube_NB_Model, Youtube_test) 


#Compare
library(gmodels) 
CrossTable(Youtube_NB_Pred, Youtube_test_lbl,    prop.chisq = FALSE, prop.t = FALSE,    dnn = c('NB Prediction', 'Youtube Actual')) 

#Laplace Estimator
Youtube_NB_Model_lapl <- naiveBayes(Youtube_train, Youtube_train_lbl,laplace = 1)
Youtube_NB_Pred_lapl <- predict(Youtube_NB_Model_lapl, Youtube_test) 

#Compare
CrossTable(Youtube_NB_Pred_lapl, Youtube_test_lbl,    prop.chisq = FALSE, prop.t = FALSE,    dnn = c('NB Prediction', 'Youtube Actual'))

